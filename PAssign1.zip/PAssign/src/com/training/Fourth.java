package com.training;

public class Fourth {

	public static void main(String[] args) {
		try {
			int a=Integer.parseInt(args[0]);
			System.out.println("valid integer");
		}
		catch(NumberFormatException e)
		{
			System.out.println("Invalid integer");
		}

	}

}
