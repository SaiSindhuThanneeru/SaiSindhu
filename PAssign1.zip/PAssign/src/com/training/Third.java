package com.training;

public class Third {

	public static void main(String args[]) {
		System.out.println("no of strings- "+args.length);
		StringBuffer s=new StringBuffer();
      for(int i=0;i<=args.length-1;i++)
      {
    	  s.append(args[i]+" ");
    	  
      }
       System.out.println(s); 
       //printing occurences of last word
       String s1=args[args.length-1];
       int count=0;
       for(int i=0;i<=args.length-1;i++)
       {
    	   if(s1.equals(args[i]))
    	   {
    		   count++;
    	   }
       }
       System.out.println("no of occurence of last word "+count);
	}
}
