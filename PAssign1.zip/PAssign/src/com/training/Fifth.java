package com.training;

public class Fifth {
	static int counter=0;
	Fifth()
	{
		System.out.println("Creating new Object");
		++counter;
		System.out.println("counter value is "+counter);
	}
	Fifth(String a)
	{
		System.out.println("parameterized constructor with content-"+a);
		++counter;
		System.out.println("counter value is "+counter);
	}
	public static void main(String[] args) {
		
  Fifth f=new Fifth();
  Fifth f1=new Fifth("Sindhuu");
	}

}
