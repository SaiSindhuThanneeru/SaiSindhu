package com.training;

public class Second {

	public static void main(String[] args) {

		//displaying length of entered string
		
      System.out.println("Length of entered string is "+args.length);
      //making args string into 1 sentence of string
      String s="";
      for(int i=0;i<=args.length-1;i++)
      {
    	  s=s+args[i]+" ";
      }
      //converting string into array
      char c1[]=s.toCharArray();  
      //logic to replace even strings to #
      for(int i=1;i<c1.length-1;i++)
     {
    	  c1[1]='#';
    	 if(i%2==1)
    	 {
    	  c1[i]='#';
    	  }
      }
      String str1=new String(c1);
      System.out.println(str1);
	}

}
